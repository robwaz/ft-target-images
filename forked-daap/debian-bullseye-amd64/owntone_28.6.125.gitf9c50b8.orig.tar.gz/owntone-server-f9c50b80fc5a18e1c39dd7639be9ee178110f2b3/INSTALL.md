# Installation instructions for OwnTone

Instructions on how to install OwnTone can be found at <https://owntone.github.io/owntone-server/installation/>
