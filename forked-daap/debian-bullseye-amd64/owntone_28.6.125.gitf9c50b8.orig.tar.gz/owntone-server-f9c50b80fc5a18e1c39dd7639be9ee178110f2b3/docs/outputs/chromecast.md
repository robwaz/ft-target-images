# Chromecast

OwnTone will discover Chromecast devices available on your network, and you
can then select the device as a speaker. There is no configuration required.
